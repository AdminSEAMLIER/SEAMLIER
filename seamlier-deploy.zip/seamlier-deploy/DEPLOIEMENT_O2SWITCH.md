# Déploiement SEAMLIER sur o2switch

## Prérequis
- Node.js 18+ installé sur o2switch
- PostgreSQL accessible (base de données à créer)
- Accès SSH au serveur

## Étapes de déploiement

### 1. Transférer les fichiers
Uploadez tout le contenu de cette archive sur votre serveur o2switch via SSH ou FTP.

### 2. Installer les dépendances
```bash
npm install --production
```

### 3. Configurer l'environnement
Renommez `.env.example` en `.env` et remplissez les valeurs :
```bash
cp .env.example .env
nano .env
```

Remplissez :
- `DATABASE_URL` : URL de connexion PostgreSQL
- `SESSION_SECRET` : une chaîne aléatoire longue (au moins 32 caractères)
- `PORT` : le port sur lequel l'application écoute (5000 par défaut)

### 4. Initialiser la base de données
```bash
npx drizzle-kit push
```

### 5. Lancer l'application
```bash
NODE_ENV=production node dist/index.cjs
```

### 6. Avec PM2 (recommandé pour la production)
```bash
npm install -g pm2
pm2 start dist/index.cjs --name seamlier -- --env production
pm2 save
pm2 startup
```

## Structure du build
- `dist/index.cjs` : Serveur Express compilé (backend + API)
- `dist/public/` : Fichiers statiques du frontend (HTML, CSS, JS)
- `migrations/` : Migrations de base de données
- `shared/` : Schéma partagé (nécessaire pour les migrations)

## Notes importantes
- L'application écoute sur le port défini dans `PORT` (défaut: 5000)
- Configurez un reverse proxy (nginx/Apache) pour rediriger le trafic HTTPS vers ce port
- L'authentification utilise Replit Auth (OIDC) - à adapter si vous changez de fournisseur d'authentification

## URL Admin
Accès admin : `https://seamlier.fr/admin/seamlier`
